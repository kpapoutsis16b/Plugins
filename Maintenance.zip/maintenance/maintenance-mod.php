﻿<?php
/**
 * Plugin Name: Λειτουργία συντήρησης
 * Plugin URI: 
 * Description: Με αυτό το plugin θέστε σε λειτουργία συντήρησης εύκολα το site σας.
 * Version: 3.3
*/

function maintenace_mode() {
      if ( !current_user_can( 'edit_themes' ) || !is_user_logged_in() ) {wp_die('<center>Η σελίδα βρίσκεται σε λειτουργία συντήρησης!!!!!!! Ζητάμε συγγνώμη για την ταλαιπωρία σας.</center>');}
}
add_action('get_header', 'maintenace_mode');
?>